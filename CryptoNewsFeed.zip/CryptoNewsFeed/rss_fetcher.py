"""
RSS feed fetcher for crypto news.
Handles fetching and parsing RSS feeds using feedparser.
"""

import feedparser
import logging
import requests
from datetime import datetime

logger = logging.getLogger(__name__)

class RSSFetcher:
    """Fetches and parses RSS feeds"""
    
    def __init__(self, rss_url):
        self.rss_url = rss_url
        
    def fetch_latest(self, limit=20):
        """
        Fetch latest articles from RSS feed
        
        Args:
            limit (int): Maximum number of articles to return
            
        Returns:
            list: List of article dictionaries
        """
        try:
            logger.info(f"Fetching RSS feed from: {self.rss_url}")
            
            # Set user agent to avoid blocking
            headers = {
                'User-Agent': 'Mozilla/5.0 (compatible; CryptoNewsBot/1.0)'
            }
            
            # Fetch the RSS feed with timeout
            response = requests.get(self.rss_url, headers=headers, timeout=30)
            response.raise_for_status()
            
            # Parse the RSS feed
            feed = feedparser.parse(response.content)
            
            if feed.bozo:
                logger.warning(f"RSS feed parsing issues: {feed.bozo_exception}")
            
            articles = []
            for entry in feed.entries[:limit]:
                article = {
                    'id': getattr(entry, 'id', entry.link),
                    'title': getattr(entry, 'title', 'No title'),
                    'link': getattr(entry, 'link', ''),
                    'summary': getattr(entry, 'summary', ''),
                    'published': getattr(entry, 'published', ''),
                    'published_parsed': getattr(entry, 'published_parsed', None),
                    'author': getattr(entry, 'author', ''),
                    'tags': [tag.term for tag in getattr(entry, 'tags', [])]
                }
                articles.append(article)
            
            logger.info(f"Successfully fetched {len(articles)} articles")
            return articles
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Network error fetching RSS feed: {e}")
            return []
        except Exception as e:
            logger.error(f"Error parsing RSS feed: {e}")
            return []
    
    def validate_feed(self):
        """Validate that the RSS feed is accessible and parseable"""
        try:
            articles = self.fetch_latest(limit=1)
            return len(articles) > 0
        except Exception as e:
            logger.error(f"RSS feed validation failed: {e}")
            return False
